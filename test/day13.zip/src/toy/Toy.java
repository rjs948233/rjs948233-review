package toy;

public interface Toy {

	//추상메소드
	String[] speackList();
	void pushBtn(String speak);
	
}
