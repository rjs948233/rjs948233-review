package anonymousTest;

public class ClassB implements InterA{

	@Override
	public void printData() {
		System.out.println("ClassB에서 구현한 메소드 오버라이딩");
	}
	
}
