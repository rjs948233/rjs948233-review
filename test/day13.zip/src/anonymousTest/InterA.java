package anonymousTest;

public interface InterA {
	//인터페이스 멤버 : 추상메소드, 상수 + jdk8 default, static, jdk9 private
	
	void printData();	
	
}
