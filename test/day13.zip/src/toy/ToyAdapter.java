package toy;

public abstract class ToyAdapter implements Toy{

   @Override
   public void pushBtn(String speak) {
      
      
   }
   
}
