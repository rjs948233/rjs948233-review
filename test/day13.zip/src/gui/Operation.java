package gui;

public interface Operation {

	    double calculate(int num1, int num2);
}
