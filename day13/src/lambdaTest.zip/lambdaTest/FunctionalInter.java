package lambdaTest;

@FunctionalInterface
public interface FunctionalInter {
	//인터페이스
	void method1();
}
